"use client";
import { motion } from "framer-motion";
import { ArrowDown, Sparkles } from "lucide-react";

const HERO_IMAGE =
  "https://d2xsxph8kpxj0f.cloudfront.net/310419663030860046/giFYBDeFxbGe42Yyw8PTCg/hero-banner-dHKNucphgnCkPtvLjoZXtv.webp";

export default function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0">
        <img
          src={HERO_IMAGE}
          alt="Luxury Villa Design"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/80 via-background/50 to-background/95" />
        <div className="absolute inset-0 bg-gradient-to-r from-background/60 to-transparent" />
      </div>

      <div className="relative z-10 container text-center px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="inline-flex items-center gap-2 px-4 py-2 mb-8 border border-gold/30 rounded-full bg-background/40 backdrop-blur-sm"
        >
          <Sparkles size={14} className="text-gold" />
          <span className="text-xs font-arabic text-gold tracking-wide">
            مجموعة حصرية من التصاميم الجاهزة
          </span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-arabic font-bold leading-tight mb-6"
        >
          <span className="text-foreground">تصاميم معمارية</span>
          <br />
          <span className="text-gold">جاهزة للتنفيذ</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.7 }}
          className="max-w-2xl mx-auto text-base sm:text-lg text-foreground/60 font-arabic leading-relaxed mb-10"
        >
          اكتشف مجموعة حصرية من التصاميم المعمارية والداخلية المصممة بعناية
          فائقة. وفّر الوقت والتكلفة مع تصاميم احترافية جاهزة للتنفيذ.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.9 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <a
            href="#designs"
            className="px-8 py-3.5 gold-gradient text-background font-arabic font-bold text-sm rounded-sm hover:opacity-90 transition-all duration-300"
          >
            استعرض التصاميم
          </a>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 1.2 }}
          className="mt-16 flex items-center justify-center gap-8 sm:gap-16"
        >
          {[
            { value: "+100", label: "تصميم جاهز" },
            { value: "+500", label: "عميل سعيد" },
            { value: "3", label: "فئات سعرية" },
          ].map((stat) => (
            <div key={stat.label} className="text-center">
              <div className="text-2xl sm:text-3xl font-price text-gold">
                {stat.value}
              </div>
              <div className="text-xs sm:text-sm text-foreground/40 font-arabic mt-1">
                {stat.label}
              </div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
