"use client";
import { motion } from "framer-motion";
import { MessageCircle, Phone, Mail, ArrowLeft } from "lucide-react";

export default function CTASection() {
  return (
    <section className="relative py-24 sm:py-32">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="relative max-w-4xl mx-auto text-center p-8 sm:p-12 lg:p-16 rounded-lg overflow-hidden"
        >
          <div className="absolute inset-0 glass-card" />
          <div className="absolute inset-0 border border-gold/20 rounded-lg" />

          <div className="relative z-10">
            <span className="text-xs font-arabic text-gold/60 tracking-widest uppercase mb-4 block">
              ابدأ مشروعك اليوم
            </span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-arabic font-bold text-foreground mb-4">
              هل أنت مستعد لتحويل <span className="text-gold">رؤيتك</span> إلى
              واقع؟
            </h2>
            <p className="max-w-xl mx-auto text-foreground/50 font-arabic text-sm sm:text-base mb-10 leading-relaxed">
              تواصل معنا الآن للحصول على استشارة مجانية أو لشراء أي تصميم من
              مجموعتنا الحصرية. فريقنا جاهز لمساعدتك في اختيار التصميم المثالي.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-10">
              <a
                href="https://wa.me/971551299880"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-8 py-3.5 gold-gradient text-background font-arabic font-bold text-sm rounded-sm hover:opacity-90 transition-all duration-300"
              >
                <MessageCircle size={16} />
                <span>تواصل عبر واتساب</span>
              </a>
            </div>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-6 text-foreground/40">
              <a
                href="tel:+971551299880"
                className="flex items-center gap-2 text-sm font-arabic hover:text-gold transition-colors"
              >
                <Phone size={14} />
                <span dir="ltr">+971 55 129 9880</span>
              </a>
              <a
                href="mailto:info@khales.ae"
                className="flex items-center gap-2 text-sm font-arabic hover:text-gold transition-colors"
              >
                <Mail size={14} />
                <span>info@khales.ae</span>
              </a>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
