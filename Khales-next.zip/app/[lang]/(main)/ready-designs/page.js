import AIBanner from "@/app/AIBanner";
import CTASection from "@/app/CTASection";
import FeaturedShowcase from "@/app/FeaturedShowcase";
import FeaturesSection from "@/app/FeaturesSection";
import HeroSection from "@/app/HeroSection";
import ProcessSection from "@/app/ProcessSection";
import SectionDivider from "@/app/SectionDivider";
import TestimonialsSection from "@/app/TestimonialsSection";

export const metadata = {
  title: "تصاميم معمارية جاهزة للتنفيذ | خالص",
  description: "اكتشف مجموعة حصرية من التصاميم المعمارية والداخلية الجاهزة.",
};

export default function DesignHubPage() {
  return (
    <div className="min-h-screen bg-background text-foreground" dir="rtl">
      <HeroSection />
      <SectionDivider />
      <ProcessSection />
      <SectionDivider />
      <FeaturedShowcase />
      <SectionDivider />
      <AIBanner />
      <SectionDivider />
      <FeaturesSection />
      <SectionDivider />
      <TestimonialsSection />
      <SectionDivider />
      <CTASection />
    </div>
  );
}
