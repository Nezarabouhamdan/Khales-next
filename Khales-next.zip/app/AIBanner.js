"use client";
import { motion } from "framer-motion";
import { Sparkles, Wand2, Cpu, Palette } from "lucide-react";

export default function AIBanner() {
  return (
    <section className="relative py-16 sm:py-20">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="relative max-w-5xl mx-auto p-8 sm:p-10 rounded-lg overflow-hidden"
        >
          <div className="absolute inset-0 bg-gradient-to-l from-olive/10 via-background/80 to-gold/10" />
          <div className="absolute inset-0 border border-gold/15 rounded-lg" />

          <div className="relative flex flex-col lg:flex-row items-center gap-8">
            <div className="flex-1">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 mb-4 border border-olive/30 rounded-full bg-olive/10">
                <Sparkles size={12} className="text-olive" />
                <span className="text-[10px] font-arabic text-olive font-bold">
                  تقنية جديدة
                </span>
              </div>
              <h3 className="text-2xl sm:text-3xl font-arabic font-bold text-foreground mb-3">
                تخصيص بالذكاء <span className="text-gold">الاصطناعي</span>
              </h3>
              <p className="text-sm text-foreground/50 font-arabic leading-relaxed mb-6">
                نستخدم أحدث تقنيات الذكاء الاصطناعي لتخصيص التصاميم الجاهزة حسب
                ذوقك. اختر تصميماً أساسياً وسنقوم بتعديله ليناسب احتياجاتك بدقة
                وسرعة فائقة.
              </p>
              <a
                href="https://wa.me/971551299880"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-2.5 gold-gradient text-background font-arabic font-bold text-sm rounded-sm hover:opacity-90 transition-opacity"
              >
                <Wand2 size={14} />
                <span>اكتشف المزيد</span>
              </a>
            </div>
            <div className="flex lg:flex-col gap-6">
              {[
                { icon: Cpu, label: "تحليل ذكي للمساحات" },
                { icon: Palette, label: "اقتراح ألوان ومواد" },
                { icon: Wand2, label: "تعديلات فورية" },
              ].map((item) => {
                const Icon = item.icon;
                return (
                  <div key={item.label} className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-gold/10 flex items-center justify-center">
                      <Icon size={16} className="text-gold" />
                    </div>
                    <span className="text-xs font-arabic text-foreground/60 hidden sm:block">
                      {item.label}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
