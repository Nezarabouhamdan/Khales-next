"use client";
import { motion } from "framer-motion";
import { Star, Quote } from "lucide-react";

const testimonials = [
  {
    name: "محمد الشامسي",
    role: "صاحب فيلا - دبي",
    text: "اشتريت تصميم فيلا جاهز من خالص ووفرت أكثر من 60% من تكلفة التصميم المخصص. الجودة ممتازة والفريق ساعدني في التعديلات البسيطة.",
    rating: 5,
  },
  {
    name: "فاطمة العلي",
    role: "مصممة داخلية - أبوظبي",
    text: "كمصممة داخلية، أستخدم تصاميم خالص الجاهزة كنقطة انطلاق لمشاريعي. التفاصيل والمواصفات دقيقة جداً وتوفر علي الكثير من الوقت.",
    rating: 5,
  },
  {
    name: "عبدالله القحطاني",
    role: "مطور عقاري - الرياض",
    text: "نستخدم تصاميم خالص الجاهزة لمشاريعنا السكنية في الرياض. الأسعار معقولة والتصاميم تناسب الذوق الخليجي بشكل مثالي.",
    rating: 5,
  },
];

export default function TestimonialsSection() {
  return (
    <section className="relative py-24 sm:py-32">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="text-center mb-16"
        >
          <span className="text-xs font-arabic text-gold/60 tracking-widest uppercase mb-4 block">
            آراء عملائنا
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-arabic font-bold text-foreground mb-4">
            ماذا يقول <span className="text-gold">عملاؤنا</span>
          </h2>
        </motion.div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {testimonials.map((t, index) => (
            <motion.div
              key={t.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.12 }}
              className="relative p-6 rounded-lg glass-card glass-card-hover transition-all duration-500"
            >
              <Quote size={24} className="text-gold/15 mb-4" />
              <p className="text-sm text-foreground/60 font-arabic leading-relaxed mb-6">
                {t.text}
              </p>
              <div className="flex items-center gap-1 mb-3">
                {Array.from({ length: t.rating }).map((_, i) => (
                  <Star key={i} size={12} className="text-gold fill-gold" />
                ))}
              </div>
              <div>
                <p className="text-sm font-arabic font-bold text-foreground">
                  {t.name}
                </p>
                <p className="text-xs text-foreground/40 font-arabic">
                  {t.role}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
