"use client";
import { motion } from "framer-motion";
import {
  Clock,
  Wallet,
  RefreshCw,
  Shield,
  Headphones,
  Globe,
} from "lucide-react";

const features = [
  {
    icon: Clock,
    titleAr: "توفير الوقت",
    descAr:
      "تصاميم جاهزة للتنفيذ فوراً بدلاً من انتظار أشهر لتصميم مخصص. ابدأ مشروعك اليوم.",
  },
  {
    icon: Wallet,
    titleAr: "توفير التكلفة",
    descAr:
      "وفّر حتى 70% مقارنة بالتصميم المخصص مع الحفاظ على أعلى معايير الجودة والاحترافية.",
  },
  {
    icon: RefreshCw,
    titleAr: "قابلية التخصيص",
    descAr:
      "كل تصميم قابل للتعديل والتخصيص حسب احتياجاتك الخاصة بتكلفة إضافية بسيطة.",
  },
  {
    icon: Shield,
    titleAr: "جودة مضمونة",
    descAr:
      "تصاميم من فريق خالص المحترف بخبرة تتجاوز عقداً من الزمن في التصميم المعماري والداخلي.",
  },
  {
    icon: Headphones,
    titleAr: "دعم مستمر",
    descAr:
      "فريق دعم متخصص لمساعدتك في اختيار التصميم المناسب والإجابة على جميع استفساراتك.",
  },
  {
    icon: Globe,
    titleAr: "توصيل فوري",
    descAr:
      "استلم ملفات التصميم الرقمية فور إتمام عملية الشراء. متاح لجميع دول الخليج.",
  },
];

export default function FeaturesSection() {
  return (
    <section className="relative py-24 sm:py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-background via-background/95 to-background" />
      <div className="relative container">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="text-center mb-16"
        >
          <span className="text-xs font-arabic text-gold/60 tracking-widest uppercase mb-4 block">
            لماذا تصاميمنا الجاهزة
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-arabic font-bold text-foreground mb-4">
            مميزات <span className="text-gold">لا تُقاوم</span>
          </h2>
        </motion.div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <motion.div
                key={feature.titleAr}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="group p-6 rounded-lg glass-card glass-card-hover transition-all duration-500 hover:shadow-[0_0_30px_rgba(102,161,9,0.08)]"
              >
                <div className="w-10 h-10 rounded-lg bg-gold/10 flex items-center justify-center mb-4 group-hover:bg-gold/15 transition-colors">
                  <Icon size={18} className="text-gold" />
                </div>
                <h3 className="text-lg font-arabic font-bold text-foreground mb-2 group-hover:text-gold transition-colors">
                  {feature.titleAr}
                </h3>
                <p className="text-sm text-foreground/40 font-arabic leading-relaxed">
                  {feature.descAr}
                </p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
