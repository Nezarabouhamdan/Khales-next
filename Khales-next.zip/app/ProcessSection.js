"use client";
import { motion } from "framer-motion";
import { Search, MousePointerClick, CreditCard, Download } from "lucide-react";

const steps = [
  {
    icon: Search,
    num: "01",
    titleAr: "تصفح المعرض",
    descAr:
      "استعرض مجموعتنا المتنوعة من التصاميم واستخدم الفلاتر للعثور على التصميم المثالي.",
  },
  {
    icon: MousePointerClick,
    num: "02",
    titleAr: "اختر تصميمك",
    descAr:
      "اطلع على تفاصيل التصميم والمخططات والصور ثلاثية الأبعاد قبل اتخاذ قرارك.",
  },
  {
    icon: CreditCard,
    num: "03",
    titleAr: "أتمم الشراء",
    descAr: "تواصل معنا عبر واتساب لإتمام عملية الشراء بأمان وسهولة.",
  },
  {
    icon: Download,
    num: "04",
    titleAr: "استلم ملفاتك",
    descAr: "احصل على جميع ملفات التصميم الرقمية فوراً وابدأ التنفيذ.",
  },
];

export default function ProcessSection() {
  return (
    <section className="relative py-24 sm:py-32">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="text-center mb-16"
        >
          <span className="text-xs font-arabic text-gold/60 tracking-widest uppercase mb-4 block">
            كيف يعمل
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-arabic font-bold text-foreground mb-4">
            أربع خطوات <span className="text-gold">بسيطة</span>
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 max-w-5xl mx-auto">
          {steps.map((step, index) => {
            const Icon = step.icon;
            return (
              <motion.div
                key={step.num}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.12 }}
                className="relative text-center group"
              >
                {index < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-10 -left-3 w-[calc(100%+1.5rem)] h-px bg-gradient-to-l from-gold/20 to-gold/5" />
                )}
                <div className="relative inline-flex items-center justify-center w-20 h-20 mb-6">
                  <div className="absolute inset-0 rounded-full border border-gold/15 group-hover:border-gold/30 transition-colors" />
                  <div className="absolute inset-2 rounded-full bg-gold/5 group-hover:bg-gold/10 transition-colors" />
                  <Icon size={24} className="text-gold relative z-10" />
                </div>
                <span className="block text-3xl font-price text-gold/20 mb-2">
                  {step.num}
                </span>
                <h3 className="text-base font-arabic font-bold text-foreground mb-2">
                  {step.titleAr}
                </h3>
                <p className="text-xs text-foreground/40 font-arabic leading-relaxed">
                  {step.descAr}
                </p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
