"use client";
import { motion } from "framer-motion";
import { ArrowLeft, Crown, Bed, Ruler, Layers } from "lucide-react";
import { designs, tierInfo } from "./designs-data";

const featured = designs.filter((d) => d.featured).slice(0, 3);
export default function FeaturedShowcase() {
  return (
    <section className="relative py-24 sm:py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-background via-background/95 to-background" />
      <div className="relative container">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="flex items-end justify-between mb-12"
        >
          <div>
            <span className="text-xs font-arabic text-gold/60 tracking-widest uppercase mb-4 block">
              تصاميم مميزة
            </span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-arabic font-bold text-foreground">
              اختيارات <span className="text-gold">المحررين</span>
            </h2>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {featured[0] && (
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="lg:col-span-7 group relative rounded-lg overflow-hidden aspect-[16/10] lg:aspect-auto lg:min-h-[500px]"
            >
              <img
                src={featured[0].image}
                alt={featured[0].titleAr}
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background/95 via-background/30 to-transparent" />
              <div className="absolute inset-0 border border-gold/10 rounded-lg group-hover:border-gold/25 transition-colors" />

              <div className="absolute bottom-0 right-0 left-0 p-6 sm:p-8">
                <div className="flex items-center gap-2 mb-3">
                  <Crown size={14} className="text-gold" />
                  <span className="text-xs font-arabic text-gold">
                    {tierInfo[featured[0].tier].nameAr}
                  </span>
                </div>
                <h3 className="text-2xl sm:text-3xl font-arabic font-bold text-foreground mb-2">
                  {featured[0].titleAr}
                </h3>
                <p className="text-sm text-foreground/50 font-arabic max-w-lg mb-4 leading-relaxed">
                  {featured[0].descriptionAr}
                </p>
                <div className="flex items-center gap-5 mb-5">
                  <div className="flex items-center gap-1.5">
                    <Ruler size={13} className="text-gold/50" />
                    <span className="text-xs text-foreground/50 font-arabic">
                      {featured[0].area}
                    </span>
                  </div>
                  {featured[0].rooms && (
                    <div className="flex items-center gap-1.5">
                      <Bed size={13} className="text-gold/50" />
                      <span className="text-xs text-foreground/50 font-arabic">
                        {featured[0].rooms} غرف
                      </span>
                    </div>
                  )}
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-2xl font-price text-gold">
                    {tierInfo[featured[0].tier].price}
                  </span>
                  <span className="text-sm text-foreground/40 font-arabic">
                    درهم
                  </span>
                  <button
                    onClick={() =>
                      window.open(
                        `https://wa.me/971551299880?text=مرحباً، أرغب في شراء تصميم "${featured[0].titleAr}"`,
                        "_blank",
                      )
                    }
                    className="mr-auto px-5 py-2 gold-gradient text-background font-arabic font-bold text-sm rounded-sm hover:opacity-90 transition-opacity"
                  >
                    اطلب الآن
                  </button>
                </div>
              </div>
            </motion.div>
          )}

          <div className="lg:col-span-5 flex flex-col gap-5">
            {featured.slice(1, 3).map((design, index) => (
              <motion.div
                key={design.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.15 * (index + 1) }}
                className="group relative rounded-lg overflow-hidden aspect-[16/9] lg:flex-1"
              >
                <img
                  src={design.image}
                  alt={design.titleAr}
                  className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/20 to-transparent" />
                <div className="absolute inset-0 border border-gold/10 rounded-lg group-hover:border-gold/25 transition-colors" />

                <div className="absolute bottom-0 right-0 left-0 p-5">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-[10px] font-arabic text-gold/70 px-2 py-0.5 border border-gold/20 rounded-sm">
                      {tierInfo[design.tier].nameAr}
                    </span>
                  </div>
                  <h3 className="text-lg font-arabic font-bold text-foreground mb-1">
                    {design.titleAr}
                  </h3>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className="text-xs text-foreground/40 font-arabic">
                        {design.area}
                      </span>
                    </div>
                    <div className="flex items-baseline gap-1">
                      <span className="text-lg font-price text-gold">
                        {tierInfo[design.tier].price}
                      </span>
                      <span className="text-[10px] text-foreground/40 font-arabic">
                        درهم
                      </span>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
